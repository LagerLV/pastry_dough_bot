import Addons.Sleep;
import org.osbot.rs07.api.Bank;
import org.osbot.rs07.api.GrandExchange;
import org.osbot.rs07.api.ui.Message;
import org.osbot.rs07.api.ui.RS2Widget;
import org.osbot.rs07.script.Script;
import org.osbot.rs07.script.ScriptManifest;
import org.osbot.rs07.api.map.Area;
import org.osbot.rs07.utility.ConditionalSleep;

import java.awt.*;
import java.text.DecimalFormat;

@ScriptManifest(name = "aDough by Lager v1.1", author = "Lager", version = 1.1, info = "Makes pastry dough to farm GP in F2P. Works with F2P restrictions in place. Auto buys ingredients and makes the dough. Start anywhere (almost), the bot should auto walk there (don't start Karamja though pls)", logo = "https://i.imgur.com/M8JBKX3.png")

public class DoughFarm extends Script {
    private long startTime;
    private int itemsMade;
    public final String formatTime(final long ms){
        long s = ms / 1000, m = s / 60, h = m / 60;
        s %= 60; m %= 60; h %= 24;
        return String.format("%02d:%02d:%02d", h, m, s);
    }

    @Override
    public void onStart() {
        log("aDough by Lager has started! Find me on https://osbot.org/forum/profile/306714-lagerlv/");
        startTime = System.currentTimeMillis();
        this.getBot().addMessageListener(this);
    }


    @Override
    public void onExit() {
        log("Thank you for using my script!");
    }


    public void onMessage(Message message) throws InterruptedException {
        String txt = message.getMessage().toLowerCase();
        if (txt.contains("mix the water and flour")) {
            itemsMade++;
        }
    }

    @Override
    public int onLoop() throws InterruptedException {
        Area geArea = new Area(3158, 3494, 3170, 3485);

        if (!geArea.contains(myPlayer())) {
            getWalking().webWalk(geArea);
        }

        if (geArea.contains(myPlayer())) { // Check if my player is in the Grand Exchange area
            if (!inventory.contains("Pot of flour") && !inventory.contains("Jug of water")) { // if inventory doesn't contain Flour AND Jug of water
                getNpcs().closest("Banker").interact("Bank"); // Interact with GE Banker
                Sleep.sleepUntil(() -> getBank().isOpen(), 8000); // Sleep until 8s have passed or bank is open
                if (inventory.contains("Pastry dough")) {
                    bank.depositAll();
                }
                if (bank.contains("Pot of flour") && bank.contains("Jug of water")) { // If bank contains flour and water
                    getBank().withdraw("Pot of flour", 9); //Withdraw 9 pots of flour
                    Sleep.sleepUntil(() -> inventory.contains("Pot of flour"), 5000);
                    if (inventory.contains("Pot of flour")) {
                        getBank().withdraw("Jug of water", 9);
                    }
                    Sleep.sleepUntil(() -> inventory.contains("Jug of water"), 5000);
                    if (bank.isOpen()) {
                        bank.close();
                    }
                }
                if (inventory.contains("Pot of flour") && inventory.contains("Jug of water")) {
                    getInventory().interact("Use", "Pot of flour");
                    Sleep.sleepUntil(() -> inventory.isItemSelected(), 5000);
                    getInventory().interact("Use", "Jug of water");
                    new ConditionalSleep(15000) {
                        @Override
                        public boolean condition() {
                            RS2Widget widget = getWidgets().getWidgetContainingText(270, "dough"); // We sleep until the widget we get when we want to combine flour + water is on screen or 15s have passed
                            return widget != null && widget.isVisible();
                        }
                    }.sleep();
                    widgets.interact(270, 15, "Make"); // We interact with the widget Make pastry dough widget
                    Sleep.sleepUntil(() -> !inventory.contains("Pot of flour"), 30000); // We sleep until inventory doesn't contain Flour or 30s have passed.
                }
                if (!bank.contains("Pot of flour") && !bank.contains("Jug of water")) { // If bank doesn't contain flour AND water
                    if (bank.contains("Pastry dough")) {
                        getBank().enableMode(Bank.BankMode.WITHDRAW_NOTE); // Enable note withdraw
                        getBank().withdrawAll("Pastry dough");
                        int doughAmount = getInventory().getItem("Pastry dough").getAmount(); // Gets the amount of pastry dough i withdrew by checking how much i have in inventory
                        Sleep.sleepUntil(() -> inventory.contains("Pastry dough"), 5000);
                        if (bank.contains("Pot")) {
                            getBank().withdrawAll("Pot");
                            Sleep.sleepUntil(() -> inventory.contains("Pot"), 5000);
                        }
                        bank.close();
                        getNpcs().closest("Grand Exchange Clerk").interact("Exchange");
                        Sleep.sleepUntil(() -> grandExchange.isOpen(), 5000);
                        grandExchange.sellItem(1954, 3, doughAmount); // Sell all the dough for 3gp (basically insta-sell)
                        sleep(2500);
                        grandExchange.sellItem(1932, 1, doughAmount); // Sell all the empty pots for 1gp (basically insta-sell)
                        sleep(2500);
                        grandExchange.collect();
                        Sleep.sleepUntil(() -> inventory.contains("Coins"), 5000);
                        grandExchange.close();
                        Sleep.sleepUntil(() -> !grandExchange.isOpen(), 3000); // Sleep until GE is closed or 3s have passed
                        getNpcs().closest("Banker").interact("Bank");
                        Sleep.sleepUntil(() -> getBank().isOpen(), 3000);
                        bank.depositAll();
                        Sleep.sleepUntil(() -> inventory.isEmpty(), 5000);
                    }
                    if (bank.contains("Coins") && inventory.contains("Coins")) { // If bank contains GP and inventory contains GP
                        bank.depositAll("Coins");
                        Sleep.sleepUntil(() -> !inventory.contains("Coins"), 5000); // Sleep until inventory doesn't contain coins or 5s have passed
                    }
                    if (bank.contains("Coins") && !bank.contains("Pastry dough")) { // If bank contains GP AND bank doesn't contain Dough
                        bank.withdrawAll("Coins");
                        Sleep.sleepUntil(() -> inventory.contains("Coins"), 8000);
                    }
                    if (inventory.contains("Coins")) {
                        int coinAmount = getInventory().getItem("Coins").getAmount(); // Store amount of GP in inventory in a variable
                        getNpcs().closest("Grand Exchange Clerk").interact("Exchange");
                        Sleep.sleepUntil(() -> grandExchange.isOpen(), 8000);
                        grandExchange.buyItem(1933, "Pot of flour", 150, coinAmount / 200); // Buys flour for 150 and quantity is the GP in inventory / 200
                        sleep(3000);
                        grandExchange.collect();
                        Sleep.sleepUntil(() -> inventory.contains("Pot of flour"), 5000);
                        grandExchange.buyItem(1937, "Jug of water", 50, coinAmount / 200); // Buys Water for 50 and quantity is the GP in inventory / 200
                        sleep(3000);
                        grandExchange.collect();
                        Sleep.sleepUntil(() -> inventory.contains("Jug of water"), 5000);
                        grandExchange.close();
                        Sleep.sleepUntil(() -> !grandExchange.isOpen(), 5000);
                        getNpcs().closest("Banker").interact("Bank");
                        Sleep.sleepUntil(() -> getBank().isOpen(), 5000);
                        bank.depositAll();
                        getBank().withdraw("Pot of flour", 9);
                        getBank().withdraw("Jug of water", 9);
                        if (bank.isOpen()) {
                            bank.close();
                        }
                    }
                }
            }
            if (inventory.getAmount("Pot of flour") > 9 || inventory.getAmount("Jug of water") > 9) { // If inventory contains more than 9 pots of flour or jugs of water
                getNpcs().closest("Banker").interact("Bank");
                bank.depositAll();
            }

        }
        return 2000;
    }

    @Override
    public void onPaint(Graphics2D g) {
        final long runTime = System.currentTimeMillis() - startTime;
        DecimalFormat f = new DecimalFormat("#");
        g.drawString("Dough made: " + f.format(itemsMade), 20, 90);
        g.drawString("aDough by Lager v1.1", 20, 50);
        g.drawString("Time Ran: " + formatTime(runTime), 20, 70);
        Point mP = getMouse().getPosition();
        g.drawLine(mP.x - 5, mP.y + 5, mP.x + 5, mP.y - 5);
        g.drawLine(mP.x + 5, mP.y + 5, mP.x - 5, mP.y - 5);
    }

}